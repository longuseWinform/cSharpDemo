﻿
namespace 串口通信终极无bug版
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BTNConnet = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.RBGetString = new System.Windows.Forms.RadioButton();
            this.RBGetByte = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RBSendString = new System.Windows.Forms.RadioButton();
            this.RBSendByte = new System.Windows.Forms.RadioButton();
            this.BTNCOMCheck = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CBBBaudrate = new System.Windows.Forms.ComboBox();
            this.CBBCOM = new System.Windows.Forms.ComboBox();
            this.TBChar = new System.Windows.Forms.TextBox();
            this.TBNews = new System.Windows.Forms.TextBox();
            this.BTNSend = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BTNConnet);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.BTNCOMCheck);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.CBBBaudrate);
            this.groupBox1.Controls.Add(this.CBBCOM);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 340);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设置";
            // 
            // BTNConnet
            // 
            this.BTNConnet.Location = new System.Drawing.Point(10, 268);
            this.BTNConnet.Name = "BTNConnet";
            this.BTNConnet.Size = new System.Drawing.Size(262, 57);
            this.BTNConnet.TabIndex = 9;
            this.BTNConnet.Text = "连接";
            this.BTNConnet.UseVisualStyleBackColor = true;
            this.BTNConnet.Click += new System.EventHandler(this.BTNConnet_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 18);
            this.label4.TabIndex = 8;
            this.label4.Text = "发送方式:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "接收方式:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.RBGetString);
            this.panel2.Controls.Add(this.RBGetByte);
            this.panel2.Location = new System.Drawing.Point(99, 211);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(173, 33);
            this.panel2.TabIndex = 6;
            // 
            // RBGetString
            // 
            this.RBGetString.AutoSize = true;
            this.RBGetString.Location = new System.Drawing.Point(101, 3);
            this.RBGetString.Name = "RBGetString";
            this.RBGetString.Size = new System.Drawing.Size(69, 22);
            this.RBGetString.TabIndex = 2;
            this.RBGetString.Text = "字符";
            this.RBGetString.UseVisualStyleBackColor = true;
            // 
            // RBGetByte
            // 
            this.RBGetByte.AutoSize = true;
            this.RBGetByte.Checked = true;
            this.RBGetByte.Location = new System.Drawing.Point(5, 3);
            this.RBGetByte.Name = "RBGetByte";
            this.RBGetByte.Size = new System.Drawing.Size(69, 22);
            this.RBGetByte.TabIndex = 2;
            this.RBGetByte.TabStop = true;
            this.RBGetByte.Text = "字节";
            this.RBGetByte.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.RBSendString);
            this.panel1.Controls.Add(this.RBSendByte);
            this.panel1.Location = new System.Drawing.Point(99, 157);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(173, 33);
            this.panel1.TabIndex = 5;
            // 
            // RBSendString
            // 
            this.RBSendString.AutoSize = true;
            this.RBSendString.Location = new System.Drawing.Point(101, 4);
            this.RBSendString.Name = "RBSendString";
            this.RBSendString.Size = new System.Drawing.Size(69, 22);
            this.RBSendString.TabIndex = 1;
            this.RBSendString.Text = "字符";
            this.RBSendString.UseVisualStyleBackColor = true;
            // 
            // RBSendByte
            // 
            this.RBSendByte.AutoSize = true;
            this.RBSendByte.Checked = true;
            this.RBSendByte.Location = new System.Drawing.Point(4, 4);
            this.RBSendByte.Name = "RBSendByte";
            this.RBSendByte.Size = new System.Drawing.Size(69, 22);
            this.RBSendByte.TabIndex = 0;
            this.RBSendByte.TabStop = true;
            this.RBSendByte.Text = "字节";
            this.RBSendByte.UseVisualStyleBackColor = true;
            // 
            // BTNCOMCheck
            // 
            this.BTNCOMCheck.Location = new System.Drawing.Point(212, 37);
            this.BTNCOMCheck.Name = "BTNCOMCheck";
            this.BTNCOMCheck.Size = new System.Drawing.Size(60, 75);
            this.BTNCOMCheck.TabIndex = 4;
            this.BTNCOMCheck.Text = "检测";
            this.BTNCOMCheck.UseVisualStyleBackColor = true;
            this.BTNCOMCheck.Click += new System.EventHandler(this.BTNCOMCheck_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "波特率:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "端口号:";
            // 
            // CBBBaudrate
            // 
            this.CBBBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBBBaudrate.FormattingEnabled = true;
            this.CBBBaudrate.Items.AddRange(new object[] {
            "9600"});
            this.CBBBaudrate.Location = new System.Drawing.Point(84, 86);
            this.CBBBaudrate.Name = "CBBBaudrate";
            this.CBBBaudrate.Size = new System.Drawing.Size(121, 26);
            this.CBBBaudrate.TabIndex = 1;
            // 
            // CBBCOM
            // 
            this.CBBCOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBBCOM.FormattingEnabled = true;
            this.CBBCOM.Location = new System.Drawing.Point(84, 37);
            this.CBBCOM.Name = "CBBCOM";
            this.CBBCOM.Size = new System.Drawing.Size(121, 26);
            this.CBBCOM.TabIndex = 0;
            // 
            // TBChar
            // 
            this.TBChar.Location = new System.Drawing.Point(306, 12);
            this.TBChar.Multiline = true;
            this.TBChar.Name = "TBChar";
            this.TBChar.Size = new System.Drawing.Size(492, 340);
            this.TBChar.TabIndex = 1;
            // 
            // TBNews
            // 
            this.TBNews.Location = new System.Drawing.Point(12, 359);
            this.TBNews.Multiline = true;
            this.TBNews.Name = "TBNews";
            this.TBNews.Size = new System.Drawing.Size(674, 79);
            this.TBNews.TabIndex = 2;
            // 
            // BTNSend
            // 
            this.BTNSend.Location = new System.Drawing.Point(692, 359);
            this.BTNSend.Name = "BTNSend";
            this.BTNSend.Size = new System.Drawing.Size(106, 79);
            this.BTNSend.TabIndex = 10;
            this.BTNSend.Text = "发送";
            this.BTNSend.UseVisualStyleBackColor = true;
            this.BTNSend.Click += new System.EventHandler(this.BTNSend_Click);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(814, 450);
            this.Controls.Add(this.BTNSend);
            this.Controls.Add(this.TBNews);
            this.Controls.Add(this.TBChar);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Proumb";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BTNCOMCheck;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CBBBaudrate;
        private System.Windows.Forms.ComboBox CBBCOM;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BTNConnet;
        private System.Windows.Forms.RadioButton RBGetString;
        private System.Windows.Forms.RadioButton RBGetByte;
        private System.Windows.Forms.RadioButton RBSendString;
        private System.Windows.Forms.RadioButton RBSendByte;
        private System.Windows.Forms.TextBox TBChar;
        private System.Windows.Forms.TextBox TBNews;
        private System.Windows.Forms.Button BTNSend;
        private System.IO.Ports.SerialPort serialPort1;
    }
}


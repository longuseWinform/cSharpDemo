﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 串口通信终极无bug版
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;//1.关闭跨线程查询
        }//1.关闭多线程
        private void Form1_Load(object sender, EventArgs e)
        {
            Thread th = new Thread(CheckCom);//2.新建一个线程执行寻找COM串口的方法，因为寻找时程序会假死
            th.IsBackground = true;//后台线程.去看3
            th.Start();
            CBBBaudrate.SelectedIndex = 0;
        }//2.主程序加载时
        void CheckCom()
        {
            CBBCOM.Items.Clear();//检测前先清空
            CBBCOM.Items.Add("检测中...");//添加一个检测中。。。给用户反馈
            CBBCOM.SelectedIndex = 0;//选中检测中。。。
            for (int i = 1; i <= 20; i++)//找20个串口，一般电脑没那么多吧，我保险起见嘿嘿
            {
                try//open失败会弹bug我们try起来
                {
                    serialPort1.PortName = "COM" + i;//一个一个试
                    serialPort1.Open();
                    CBBCOM.Items.Add(serialPort1.PortName);//打开成功了就添加到下拉框集合
                    serialPort1.Close();//开了门记得关
                }
                catch
                {
                    serialPort1.Close();//open失败了关一下保险一点
                }
            }
            try
            {
                CBBCOM.Items.Remove("检测中...");//移除这个提示，防止用户乱选
                CBBCOM.SelectedIndex = CBBCOM.Items.Count - 1;//帮用户选择最后一个
            }
            catch { }
        }//3.检测串口程序
        private void BTNCOMCheck_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(CheckCom);//开多线程的原因是防止程序假死
            th.IsBackground = true;
            th.Start();
        }//4.按钮手动检测串口程序

        private void BTNConnet_Click(object sender, EventArgs e)
        {
            if (BTNConnet.Text == "连接")//通过按钮text判断要执行的事件
            {
                try//open可能弹bug所以咱们try起来
                {
                    serialPort1.PortName = CBBCOM.SelectedItem.ToString();//串口号赋值
                    serialPort1.BaudRate = int.Parse(CBBBaudrate.Text);//波特率赋值
                    serialPort1.Open();//尝试打开
                    MessageBox.Show(serialPort1.PortName + "连接成功", "提示");//各种提示
                    MsgShow(serialPort1.PortName + "连接成功！！！");
                    BTNConnet.Text = "断开";//按钮文本改变，为下次按按钮执行的事件改变做铺垫
                }
                catch
                {
                    serialPort1.Close();//确认它得关掉
                    MessageBox.Show("连接失败", "错误");//提示出错了
                }
            }
            else//这时按钮的文本是断开，我们要写断开串口的DEMO
            {
                serialPort1.Close();//断开
                MessageBox.Show(serialPort1.PortName + "连接已断开!!!", "提示");//各种提示
                MsgShow(serialPort1.PortName + "连接已断开");
                BTNConnet.Text = "连接";//既然断开了，下一步就该要重新连接了
            }
        }//5.连接串口按钮
        private void BTNSend_Click(object sender, EventArgs e)
        {
            if (RBSendByte.Checked)//判断选择发送的方式
            {
                Thread th = new Thread(SendByte);//发送会假死，开线程
                th.IsBackground = true;
                th.Start();
            }
            else
            {
                Thread th = new Thread(SendString);//同上
                th.IsBackground = true;
                th.Start();
            }
            TBNews.Focus();//发完聚个焦，提升用户体验
        }//6.发送数据

        void SendByte()
        {
            try //如果输入的不是字节不属于0-F的数，会触发Bug。我们try起来
            {
                for (int i = 0; i < (TBNews.Text.Length - TBNews.Text.Length % 2) / 2; i++)//偶数就两个两个长度发，发完--奇数也是两两发，最后一个单独发
                {
                    byte[] buffer = new byte[1];
                    buffer[0] = Convert.ToByte(TBNews.Text.Substring(i * 2, 2), 16);//两两发，i是上一次发到的位置
                    serialPort1.Write(buffer, 0, 1);
                }
                if (TBNews.Text.Length % 2 == 1)
                {
                    byte[] buffer = new byte[1];
                    buffer[0] = Convert.ToByte(TBNews.Text[TBNews.Text.Length - 1].ToString(), 16);//最后一个单独存一个字节单独发
                    serialPort1.Write(buffer, 0, 1);
                }
            }
            catch
            {
                MessageBox.Show("输入错误，请重新输入", "错误");//弹个提示，清个屏，聚个焦，用户体验嘎嘎好
                TBNews.Text = "";
                TBNews.Focus();
            }

        }//6.1发送字节
        void SendString()
        {
            byte[] buffer = new byte[1024];//1M够用了吧
            buffer = Encoding.UTF8.GetBytes(TBNews.Text);//先使用utf-8装字节
            serialPort1.Write(buffer, 0, buffer.Length);//发字节
        }//6.2发送字符串
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (RBGetString.Checked)
            {
                byte[] buffer = new byte[1024];//发一M收一M
                int n = 0;//这个n要给下面用所以在try外部定义
                try { n = serialPort1.Read(buffer, 0, buffer.Length); }

                catch { MsgShow("数据过大，通信爆炸"); }
                string GetStr = Encoding.UTF8.GetString(buffer,0,n);//将有效字节解码
                MsgShow(GetStr);//显示
            }
            else
            {
                while (true)//读不到尾就一直读读到尾为止
                {
                    byte[] buffer = new byte[1024];//接收字节数组
                    int n = -1;
                    try { n = serialPort1.Read(buffer, 0, buffer.Length); }//读取字节数组，存到buffer里面
                    catch { break; }//报错跳出循环
                    if (n==-1)
                    {
                        break;//读完跳出循环
                    }
                    for (int i = 0; i < n; i++)
                    {
                        MsgShow(buffer[i] > 15 ? "0X" + Convert.ToString(buffer[i], 16).ToUpper() : "0X0" + Convert.ToString(buffer[i], 16).ToUpper());
                    }               //判断是否为两位？两位就加“0X”显示：一位就加“0X0”显示
                }
            }
        }//7.接收数据
        void MsgShow(string s)//让信息框添加数据变简单
        {
            TBChar.AppendText(s+"\r\n");
        }
       
        
       
    }
}
